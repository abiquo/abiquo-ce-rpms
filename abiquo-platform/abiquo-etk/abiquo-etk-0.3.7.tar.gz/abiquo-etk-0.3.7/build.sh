SIGN_PKGS=0
MOCK_PROFILE=centos-5.5-x86_64
PKG_NAME=abiquo-aim
BUILDBASE=~/rpmbuild

source ~/Work/rpmdev/build.sh
