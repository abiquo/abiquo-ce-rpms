if ARGV[0] == 'disable-kvm-fullvirt'

  ARGV.shift

  f = ABIQUO_BASE_DIR + '/config/virtualfactory.xml' 
  if File.exist? f
    config_set_node(f, 'hypervisors/kvm/fullVirt', 'false', true)
  else
    $stderr.puts "Virtual Factory not found in this server. Skipping"
  end
end
