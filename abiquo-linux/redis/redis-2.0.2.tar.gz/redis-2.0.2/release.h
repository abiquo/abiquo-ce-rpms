#define REDIS_GIT_SHA1 "d7554ada"
#define REDIS_GIT_DIRTY "       0"
